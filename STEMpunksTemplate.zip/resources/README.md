# website

This repo is for the development of the L&N STEMpunks website.

It should always stay up to date and be under development of multiple users. 

If you have any problems with the website, you can contact josh@lnstempunks.org.

The web development team's issue and changes list is hosted on Trello. Let us know if you want to take a peek.

Thanks,  
The L&N STEMpunks Team
