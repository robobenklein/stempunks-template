# stempunks-template
L&N STEMpunks website

This is a Joomla Template remake of our current site, so we can integrate it into a CMS and simplify the codebases.
